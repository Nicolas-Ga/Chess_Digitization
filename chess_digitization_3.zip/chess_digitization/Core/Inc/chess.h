/*
 * chess.h
 *
 *  Created on: Jan 6, 2022
 *      Author: Neo
 */

#ifndef INC_CHESS_H_
#define INC_CHESS_H_

float* segment_board(float * input, const int img_height, const int img_width, float * output);

#endif /* INC_CHESS_H_ */
