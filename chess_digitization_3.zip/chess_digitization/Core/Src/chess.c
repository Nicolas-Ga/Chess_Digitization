/*
 * chess.c
 *
 *  Created on: Jan 6, 2022
 *      Author: nicolas
 */

float* segment_board(float * input, const int in_height, const int in_width, const int num_out){
	if (num_out < 2){ //make a copy of the original image
		return input;
	}
	int out_height = in_height/(sqrt(num_out));
	int out_width = in_width/(sqrt(num_out));
	int squares_across = in_width/out_width; //should be 8 for a chess board, how many columns input is segmented by
	int squares_down = in_height/out_height; //should be 8 for a chess board, how many rows input is segmented by
	float *out = (float*) malloc(out_width * out_height * squares_down * squares_across * sizeof(float));
	//Output has squares_across*squares_down (or num_out) images of size out_width by out_height

	for (int x = 0; x < squares_down; x++){
		for (int y = 0; y <  squares_across; y++){
			for (int i = 0; i <  out_width; i++){
					for (int j = 0; j < out_height; j++){
						out[(x*squares_across*out_height*out_width)+(y*out_height*out_width) + (i*out_width) + j] = input[(x*(in_width*out_height))+(y*out_width)+(i*in_width)+j];
					}
			}
		}
	}

	return out;
}
