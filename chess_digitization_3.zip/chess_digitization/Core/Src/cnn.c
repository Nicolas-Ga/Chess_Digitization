/*
 * cnn.c
 *
 *  Created on: Nov 23, 2021
 *      Author: nicolas
 */

//Same padding before convolution
void pad(float * input, float * output, const int rows, const int columns, const int channels){
	int output_rows = rows+2;
	int output_columns = columns+2;
	for (int x = 0; x < channels; x++) {
		for (int i = 0; i < output_rows; i++) {
			for (int j = 0; j < output_columns; j++) {
				if ((i == 0 || j == 0) || (i == (rows+1) || j == (columns+1))) {
					output[(x*output_rows*output_columns) + (i * output_columns) + j] = 0;
				} else {
					output[(x*output_rows*output_columns) + (i * output_columns) + j] = input[(x*rows*columns) + ((i - 1)*columns) + (j - 1)];
				}
			}
		}
	}
}

//Convolutional Layer Implementation
void conv(float * input, float * output, float * w, float * b, const int input_rows, const int input_columns, const int input_channels, const int output_rows, const int output_columns, const int output_channels){
	//Assumes weights have filter arrays of size 3x3
	float sum = 0;
	for (int y = 0; y < output_channels; y++) { //For each output channel
		for (int i = 0; i < output_rows; i++) { //For every row of our output
			for (int j = 0; j < output_columns; j++) { //For every column of the current row of our output
				for (int x = 0; x < input_channels; x++) { // For every input channel
					for (int u = 0; u < 3; u++) { //For every row of our current filter weights
						for (int v = 0; v < 3; v++) { //For every column of our current filter weights
							sum += input[(x*input_rows*input_columns) + ((i + u)*input_columns) + j + v] * w[(y*input_channels*9) + (x * 9) + (u * 3) + v];
						}
					}
				}
				output[(y*output_rows*output_columns) + (i*output_columns) + j] = sum + b[y];
				sum = 0;
			}
		}
	}
}

//Relu Activation Implementation
void relu(float * input, const int rows, const int columns, const int channels){
	for (int x = 0; x<channels; x++){
		for(int i=0; i<rows; i++){
			for(int j=0; j<columns; j++){
				if ((input[(x*rows*columns)+(i*columns)+j])< 0){
					input[(x*rows*columns)+(i*columns)+j] = 0;
				}
			}
		}
	}
}

//Pooling Layer Implementation
void pool(float * input, float * output, const int input_rows, const int input_columns, const int output_rows, const int output_columns, const int channels){
	float comparison = 0;
	float temp = 0;
	//We are going to segment the input's arrays into 2x2 segments, and determine the maximum
	//value present in each 2x2 to put into the output's matrices
	for (int x = 0; x < channels; x++) { //For each channel in the output array
		for (int i = 0; i < output_rows; i++) { //For each row in the output channel
			for (int j = 0; j < output_columns; j++) { //For each column in the current output channel
				//First value of the current 2x2 segment in the current output channel
				comparison = input[(x*input_columns*input_rows) + ((i * input_columns) * 2) + (j * 2)];
				for (int u = 0; u < 2; u++) { //Go through the 2x2 segment and find the highest value in it
					for (int v = 0; v < 2; v++) {
						temp = input[(x *input_columns*input_rows) + ((i * input_columns) * 2)+ (j * 2) + (u * input_columns) + v];
						if (temp > comparison) {
							comparison = temp;
						}
					}
				}
				output[(x *output_columns*output_rows) + (i * output_columns) + j] = comparison;
				comparison = 0;
				temp = 0;
			}
		}
	}
}

//Dense Layer Implementation
void dense(float * x, float * w, float * b, double * y, const int channels, const int input_width, const int input_height, const int output_size){
// Given input x, output y
// y_i, x_j
	double sum = 0;
	double result[10] = {0};
	for(int i = 0; i<input_height; i++){ //for each row in x
		for(int j = 0; j<input_width; j++){//for each column in x
			for(int c=0; c<channels; c++){//for each channel in x
				for(int v =0; v<output_size;v++){ //for each column in weights
					result[v] += w[(i*input_width*channels*output_size)+(j*channels*output_size)+(c*output_size)+v]*x[(c*input_width*input_height)+(i*input_width)+j];
				}
			}

		}
	}

	//bias
	for(int i=0; i<output_size;i++){
		result[i] += b[i];
		y[i] = result[i];
	}


	sum = 0;
	for(int i=0; i<output_size; i++){
		double temp = exp(y[i]);
		sum += temp;
	}
	for(int i = 0; i<output_size; i++){
		y[i] = exp(y[i])/(sum);
	}

}

