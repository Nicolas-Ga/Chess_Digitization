/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file            : usb_host.c
  * @version         : v1.0_Cube
  * @brief           : This file implements the USB Host
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "usb_host.h"
#include "usbh_core.h"
#include "usbh_msc.h"

/* USER CODE BEGIN Includes */
#include "ff.h"
#include "jwread.h"
FATFS USBH_fatfs;
FIL MyFile;
FRESULT res;
uint32_t bytesWritten;
uint8_t rtext[4096];
uint8_t wtext[1] = ",";
uint8_t new_line[1] ="\n";
uint8_t name[10];//name of the file
uint16_t counter=0;
uint32_t i=0;
extern char USBHPath [];  /* USBH logical drive path */
extern int file_ready;

/* USER CODE END Includes */

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USB Host core handle declaration */
USBH_HandleTypeDef hUsbHostFS;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;

/*
 * -- Insert your variables declaration here --
 */
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*
 * user callback declaration
 */
static void USBH_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */

void userFunction(void) {
	uint16_t bytesread;
	if (Appli_state == APPLICATION_READY) {
			sprintf(name,"demo.txt");
			/*Create a file*/
			res = f_open(&MyFile,name,FA_CREATE_ALWAYS |FA_WRITE);
			if (res != FR_OK ) {
				/* Creation failed */
				Error_Handler();
			} else {
				/*write message to the file. Use variable wtext, bytesWritten*/
				res =f_write(&MyFile,wtext,sizeof(wtext),&bytesWritten);

				/*close the file*/
				f_close(&MyFile);
				/*check number of written bytes*/
				if ((bytesWritten == 0) || (res != FR_OK)) {
					Error_Handler();
				} else{
					// Read the message
					if (f_open(&MyFile,name,FA_READ) != FR_OK ) {
						Error_Handler();
					}else{
						res= f_read(&MyFile,rtext,sizeof(rtext), &bytesread);

						if ((bytesread == 0) || (res != FR_OK)) {
							Error_Handler();
						}
						if (f_close(&MyFile) != FR_OK) {
							Error_Handler();
						}
						while(1);
					}
				}
			}
	}
}

void read_bmp(uint8_t file_name[]) {
	uint16_t bytesread;
	if (Appli_state == APPLICATION_READY && file_ready == 0) {
			if (f_open(&MyFile,file_name,FA_READ) != FR_OK ) {
				Error_Handler();
			}else{
				res= f_read(&MyFile,rtext,sizeof(rtext), &bytesread);

				if ((bytesread == 0) || (res != FR_OK)) {
					Error_Handler();
				}
				if (f_close(&MyFile) != FR_OK) {
					Error_Handler();
				}

				file_ready = 1;
			}

	}
}

float * read_txt(uint8_t file_name[], int num_line) {
	uint16_t bytesread;
	if (Appli_state == APPLICATION_READY) {
			if (f_open(&MyFile,file_name,FA_READ) != FR_OK ) {
				Error_Handler();
			}else{
				float * array_out = (float *) malloc(sizeof(float)*num_line);
				for(int i = 0; i < num_line; i++){
					memset(rtext,0,sizeof(rtext));
					f_gets(rtext, sizeof(rtext), &MyFile);
					array_out[i] = atof(rtext);
					int _ = 0;
				}
				if (f_close(&MyFile) != FR_OK) {
					Error_Handler();
				}
				return array_out;
			}
	}
}

void reverse(char* str, int len)
{
    int i = 0, j = len - 1, temp;
    while (i < j) {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// Converts a given integer x to string str[].
// d is the number of digits required in the output.
// If d is more than the number of digits in x,
// then 0s are added at the beginning.
int intToStr(int x, char str[], int d)
{
    int i = 0;
    while (x) {
        str[i++] = (x % 10) + '0';
        x = x / 10;
    }

    // If number of digits required is more, then
    // add 0s at the beginning
    while (i < d)
        str[i++] = '0';

    reverse(str, i);
    str[i] = '\0';
    return i;
}

// Converts a floating-point/double number to a string.
void ftoa(float n, char* res, int afterpoint)
{
    // Extract integer part
    int ipart = (int)n;

    // Extract floating part
    float fpart = n - (float)ipart;

    // convert integer part to string
    int i = intToStr(ipart, res, 0);

    // check for display option after point
    if (afterpoint != 0) {
        res[i] = '.'; // add dot

        // Get the value of fraction part upto given no.
        // of points after dot. The third parameter
        // is needed to handle cases like 233.007
        fpart = fpart * pow(10, afterpoint);

        intToStr((int)fpart, res + i + 1, afterpoint);
    }
}

int count_digits(int in)
{
	int count = 0;
	do{
		in /= 10;
		++count;
	} while (in != 0);

	return count;
}

void write_txt(uint8_t file_name[], float * output){
	uint16_t bytesread;
	if (Appli_state == APPLICATION_READY) {
		/*Create a file*/
		res = f_open(&MyFile,file_name,FA_CREATE_ALWAYS |FA_WRITE);
		if (res != FR_OK ) {
			/* Creation failed */
			Error_Handler();
		} else {
			/*write message to the file. Use variable wtext, bytesWritten*/
			// TODO: Adapt to your own code
			for(int i = 0; i < 14; i++){
				for(int j = 0; j < 14; j++){
					int temp_in = output[i*14+j];
					if(temp_in == 0){
						uint8_t out_mine[1] = "0";
						res =f_write(&MyFile,out_mine,sizeof(out_mine),&bytesWritten);
						res =f_write(&MyFile,wtext,sizeof(wtext),&bytesWritten);
					}
					else{
						int num_digits = count_digits(temp_in);
						if(num_digits == 1){
							uint8_t out_mine1[1];
							sprintf(out_mine1,"%d",temp_in);
							res =f_write(&MyFile,out_mine1,sizeof(out_mine1),&bytesWritten);
							res =f_write(&MyFile,wtext,sizeof(wtext),&bytesWritten);
						}
						else if (num_digits == 2){
							uint8_t out_mine2[2];
							sprintf(out_mine2,"%d",temp_in);
							res =f_write(&MyFile,out_mine2,sizeof(out_mine2),&bytesWritten);
							res =f_write(&MyFile,wtext,sizeof(wtext),&bytesWritten);
						}
						else{
							uint8_t out_mine3[3];
							sprintf(out_mine3,"%d",temp_in);
							res =f_write(&MyFile,out_mine3,sizeof(out_mine3),&bytesWritten);
							res =f_write(&MyFile,wtext,sizeof(wtext),&bytesWritten);
						}
					}

					/*check number of written bytes*/
					/*if ((bytesWritten == 0) || (res != FR_OK)) {
						Error_Handler();
					}
					*/
				}
				res =f_write(&MyFile,new_line,sizeof(new_line),&bytesWritten);
			}

			/*close the file*/
			f_close(&MyFile);
		}

	file_ready = 1;
	}
}
/* USER CODE END 1 */

/**
  * Init USB host library, add supported class and start the library
  * @retval None
  */
void MX_USB_HOST_Init(void)
{
  /* USER CODE BEGIN USB_HOST_Init_PreTreatment */

  /* USER CODE END USB_HOST_Init_PreTreatment */

  /* Init host Library, add supported class and start the library. */
  if (USBH_Init(&hUsbHostFS, USBH_UserProcess, HOST_FS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_RegisterClass(&hUsbHostFS, USBH_MSC_CLASS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_Start(&hUsbHostFS) != USBH_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_HOST_Init_PostTreatment */

  /* USER CODE END USB_HOST_Init_PostTreatment */
}

/*
 * Background task
 */
void MX_USB_HOST_Process(void)
{
  /* USB Host Background task */
  USBH_Process(&hUsbHostFS);
}
/*
 * user callback definition
 */
static void USBH_UserProcess  (USBH_HandleTypeDef *phost, uint8_t id)
{
  /* USER CODE BEGIN CALL_BACK_1 */
  switch(id)
  {
  case HOST_USER_SELECT_CONFIGURATION:
  break;

  case HOST_USER_DISCONNECTION:
  Appli_state = APPLICATION_DISCONNECT;
  break;

  case HOST_USER_CLASS_ACTIVE:
  Appli_state = APPLICATION_READY;
  break;

  case HOST_USER_CONNECTION:
  Appli_state = APPLICATION_START;

  if (f_mount(&USBH_fatfs,USBHPath,0) != FR_OK)
  {
	  Error_Handler();
  }
  break;

  default:
  break;
  }
  /* USER CODE END CALL_BACK_1 */
}

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
