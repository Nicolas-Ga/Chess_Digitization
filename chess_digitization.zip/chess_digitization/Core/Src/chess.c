/*
 * chess.c
 *
 *  Created on: Jan 6, 2022
 *      Author: nicolas
 */
#include "chess.h"
#include "cnn.h"
#include "string.h"
#include "fatfs.h"
#include "usb_host.h"

//Takes a picture of a chess board and turns it into a 8x8 array detailing which piece is where
int* create_board(float * input, const int in_height, const int in_width, const int num_out, const int out_height, const int out_width, const int img_num){
	int squares_across = in_width/out_width; //should be 8 for a chess board, how many columns input is segmented by
	int squares_down = in_height/out_height; //should be 8 for a chess board, how many rows input is segmented by
	int *board = (int*) malloc(squares_across * squares_down * sizeof(int));
	float *cur_img = (float*) malloc(out_width * out_height * sizeof(float));
	//Focus on each individual square one at a time; take the square from the input, export it as a csv (if needed),
	//run it through the CNN to determine which piece is there, place the piece on the output board array
	int piece;
	for (int x = 0; x < squares_down; x++){
		for (int y = 0; y <  squares_across; y++){
			for (int i = 0; i <  out_width; i++){
				for (int j = 0; j < out_height; j++){
					cur_img[(i*out_width) + j] = input[(x*(in_width*out_height))+(y*out_width)+(i*in_width)+j];
				}
			}
			piece = chess_CNN(cur_img, out_height, out_width); //Determine which piece this is
			board[(x*squares_down) + y] = piece; //Write to board
			printf("%d, ", piece);
			//export_picture(cur_img, out_height, out_width, x, y, img_num); //export cur_img as csv to USB drive
		}
		printf("\n");
	}

	free(cur_img);
	return board;
}

void export_picture(float * input, const int row, const int col, const int x_title, const int y_title, const int img_num){
	//Write out first segmented image as txt file to usb
	uint8_t name[10];
	sprintf(name, "%d_%d_%d.csv", img_num, x_title, y_title);
	write_txt(name,input,row,col);
}

int chess_CNN(float * input, const int row, const int col){
	int filter_count = 8;
	uint8_t name[10];
	//First Layer
	sprintf(name, "b1.txt");
	float *b1 = read_txt(name, 8);
	sprintf(name, "w1.txt");
	float *w1 = read_txt(name, 72);
	float * layer1_result = layer(input, b1, w1, row, col, 1, filter_count);
	free(b1);
	free(w1);

	//Second Layer
	sprintf(name, "b2.txt");
	float *b2 = read_txt(name, 8);
	sprintf(name, "w2.txt");
	float *w2 = read_txt(name, 576);
	float * layer2_result = layer(layer1_result, b2, w2, (row/2), (col/2), filter_count, filter_count);
	free(b2);
	free(w2);
	free(layer1_result);

	//Dense Layer
	sprintf(name, "b4.txt");
	float *b4 = read_txt(name, 13);
	sprintf(name, "w4.txt");
	float *w4 = read_txt(name, 6656);

	float *result = (float*) malloc(13 * sizeof(float));

	dense(layer2_result, w4, b4, result, filter_count, (row/4), (col/4), 13);
	int piece = -1;
	float value = 0;
	for (int i = 0; i < 13; i++) {
		//printf("     The prediction of number %d is: %.15f \n",i, result[i]);
		if (value<result[i]){
			value = result[i];
			piece = i;
		}
	}

	free(layer2_result);
	free(result);
	free(b4);
	free(w4);
	return piece;
}
