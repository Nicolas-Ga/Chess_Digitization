/*
 * chess.h
 *
 *  Created on: Jan 6, 2022
 *      Author: Nicolas
 */

#ifndef INC_CHESS_H_
#define INC_CHESS_H_

int* create_board(float * input, const int in_height, const int in_width, const int num_out, const int out_height, const int out_width, const int img_num);
void export_picture(float * input, const int row, const int col, const int x_title, const int y_title, const int img_num);
int chess_CNN(float * input, const int row, const int col);
#endif /* INC_CHESS_H_ */
