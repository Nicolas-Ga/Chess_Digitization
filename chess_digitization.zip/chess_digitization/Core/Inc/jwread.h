/*
 * jwread.h
 *
 *  Created on: Nov 8, 2021
 *      Author: catchc-w
 */

#ifndef INC_JWREAD_H_
#define INC_JWREAD_H_

float * ProcessBmp(char *textin, const int width, const int height);

#endif /* INC_JWREAD_H_ */
