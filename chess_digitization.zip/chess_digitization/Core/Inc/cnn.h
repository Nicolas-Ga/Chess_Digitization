/*
 * cnn.h
 *
 *  Created on: Nov 23, 2021
 *      Author: nicolas
 */

#ifndef SRC_CNN_H_
#define SRC_CNN_H_
void pad(float * input, float * output, const int rows, const int columns, const int channels);
void conv(float * input, float * output, float * w, float * b, const int input_rows, const int input_columns, const int input_channels, const int output_rows, const int output_columns, const int output_channels);
void relu(float * input, const int rows, const int columns, const int channels);
void pool(float * input, float * output, const int input_rows, const int input_columns, const int output_rows, const int output_columns, const int channels);
void dense(float * x, float * w, float * b, float * y, const int channels, const int input_width, const int input_height, const int output_size);
float* layer(float * input, float * biases, float * weights, const int row, const int col, const int channel_count, const int filter_count);
#endif /* SRC_CNN_H_ */
